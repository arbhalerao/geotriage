"""
the geotriage authoring contract

a model declares the bands it needs and the scores it produces, then implements `run(bands) -> dict`
a provider declares where scenes come from and how each of its bands maps onto a normalized name and physical units

    from geotriage import Model, Requires, Score, Thresholds

    class MyDetector(Model):
        slug = "my-detector"
        name = "My Detector"
        requires = Requires(bands=["green", "nir"], max_cloud_cover=30)
        scores = {
            "my_index": Score(primary=True, thresholds=Thresholds(green=(0.3, 1.0),
                                                                  yellow=(0.0, 0.3))),
        }

        def run(self, bands):
            return {"my_index": ((bands.green - bands.nir) / (bands.green + bands.nir)).nanmean()}

everything here is pure: numpy and the standard library, nothing from the platform
"""

from geotriage.bands import Bands, Raster
from geotriage.descriptor import describe, describe_model, describe_provider
from geotriage.compat import (
    CompatibilityResult,
    CompatReason,
    build_normalized_assets,
    check_compatibility,
)
from geotriage.model import Model, Prefilter, Requires, Score, Thresholds, split_output
from geotriage.provider import ApiKeyAuth, Auth, Band, BearerAuth, Collection, NoAuth, PlanetaryComputerSAS, Provider
from geotriage.validate import (
    check_collection,
    check_descriptor,
    check_model,
    check_provider,
)

__version__ = "0.1.0"

__all__ = [
    "ApiKeyAuth",
    "Auth",
    "Band",
    "Bands",
    "BearerAuth",
    "Collection",
    "CompatReason",
    "CompatibilityResult",
    "Model",
    "NoAuth",
    "PlanetaryComputerSAS",
    "Prefilter",
    "Provider",
    "Raster",
    "Requires",
    "Score",
    "Thresholds",
    "build_normalized_assets",
    "check_collection",
    "check_descriptor",
    "check_compatibility",
    "check_model",
    "check_provider",
    "describe",
    "describe_model",
    "describe_provider",
    "split_output",
]
